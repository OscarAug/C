 /*************************************************************
 *	Name: String.cpp				  				  		  *
 *	Author: Brittany Harbison & Peng Gao 			    	  *
 *	Date: April 25, 2017						  			  *
 *	Purpose: custom string creation with class				  *
 *************************************************************/
#include "String.h"

String::String (char* charArray)
{
	size = strlen(charArray);
	text = new char[size+1];
	strcpy(text, charArray);
	text[size] = '\0';
}
String::~String()
{
	delete[]text;
}
int String::find(char delimiter, int start)
{
	int delimiterLocation;
	
	if(start > 0 || start >= size)
		return -1;
	
	delimiterLocation = 0;
	for (int i = start; i < size; i++)
	{
		if (text[i] == delimiter)
		{
			delimiterLocation = i;
			break;
		}
	}
	if (delimiterLocation == 0)
		return -1;
	
	return delimiterLocation;
}
int String::compare(String* str)
{
	return strcmp(text, str->text);
}
String* String::substr (int start, int end)
{  
	int count;

	if(start > end || start < 0)
		return NULL;
	if(start > size || end > size)
		return NULL;
	
	int substrLength = (end - start)+1;
	char* substrBuffer = new char[substrLength+1];
	
	for(int i = start; i <= end; i++)
	{
		substrBuffer[count] = text[i];
		count++;
	}
	substrBuffer[substrLength] = '\0';
	
	String* substr = new String(substrBuffer); 
	delete [] substrBuffer;
	
	return substr;
}
void String::display()
{
	cout << text;
	
	return;
}
int String::getSize()
{
	return size;
}
char* String::getString()
{
	return text;
}
bool String::isEmpty()
{
	bool empty;
	
	if (getSize() == 0)
		empty = true;
	else
		empty = false;
	
	return empty;
}