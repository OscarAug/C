 /*************************************************************
 *	Name: String.cpp				  				  		  *
 *	Author: Brittany Harbison & Peng Gao 			    	  *
 *	Date: April 25, 2017						  			  *
 *	Purpose: custom string creation with class				  *
 *************************************************************/ 
 
 #ifndef _STRING_H
 #define _STRING_H 
 
 #include <iostream>
 #include <cstring>
 using namespace std;
 
 class String
 {
	 private:
		char* text;
		int size;
	 public:
		String(char*);
		~String();
		int find (char, int);
		int compare (String*);
		String* substr (int, int);
		void display();
		int getSize();
		char* getString();
		bool isEmpty();
 };
 
 #endif