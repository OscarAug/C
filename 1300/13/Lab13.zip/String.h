/*
	File Name: String.h
	Author: Emily Qualls & Xu Chen
	Date: April 25, 2017
	Purpose: Creates the string class and houses the header files along with the function prototypes
*/

#ifndef STRING_H
#define STRING_H

#include <iostream>
#include <cstring>

using namespace std;

class String
{
	private:
		char* text;
		int size;
	
	public:
		String(char*);
		bool isEmpty();
		void display();
		int getSize();
		char* getString();
		int find(char, int);
		int compare(String*);
		String* substr(int, int);
		~ String();
};

#endif