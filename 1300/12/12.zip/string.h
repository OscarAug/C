/*
    File Name:Lab12
	Author: Peng Gao
	Date:04/18/17
	Purpose:string, structure
*/

#ifndef string_h
#include <iostream>
#include <string>
#include <cstring>
#include <fstream>
#include <iomanip>


using namespace std;


struct string
{
	int size;
	const char* text
}




#endif