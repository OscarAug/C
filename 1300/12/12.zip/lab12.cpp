/*
    File Name:Lab12
	Author: Peng Gao
	Date:04/18/17
	Purpose:string, structure
*/

#include "string.h"

int main ()
{
	int find (String* str, char delimiter, int start)；
	String* substr (string* str, int start, int end)；
	int compare (String* str1, String* str2)；
	String* createstring (const char* charArray)；
	void destroyString (String* str)；
	void display (String* str)；

	return 0; 
}