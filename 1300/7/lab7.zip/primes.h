/*
	File Name:Primes.cpp
	Athour: Peng Gao
	Date: March 19
	Purpose: lab7
*/
#ifnder PRIMES_H
#define PRIMES_H

#include <string>
#include <iostream>
#include <fstream>
#include <cmath>

using namespace std; 

bool isPrimeFlag (int);

void primes (int, int, int, int, string)

#endif