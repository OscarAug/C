/*
	File Name:donut.h
	Athour: Peng Gao
	Date: April 7
	Purpose: Research of donut
*/

#ifndef DONUT_H
#define DONUT_H

//#includes and namespace

#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

//function prototypes
void enterData(int, int*, int*, int*);

#endif
