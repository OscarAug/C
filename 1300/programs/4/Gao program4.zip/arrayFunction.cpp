/*
	File Name:arrayFunction.cpp
	Athour: Peng Gao
	Date: April 7
	Purpose: Research of donut
*/

#include "arrayHeader.h"

/*make array*/
int* makeArray_numD(int size)
{
	int* numDonuts = new int[size];
	for (int i = 0; i < size; i++)
		numDonuts[i] = 0;
	return numDonuts;
}

/*make different type of donut*/
int* makeArray_tpD(int size)
{
	int* typeDonuts = new int[size];
	for(int i = 0; i < size; i++)
		typeDonuts[i] = 0;
	return typeDonuts;
}

/*make the loaction of each donut store*/
int* makeArray_location(int size)
{
	int* location = new int[size];
	for (int i = 0; i < size; i++)
		location[i] = 0;
	return location;
}

/*make largest number  of donuts eaten*/
int getLagest(int*numDonuts,int size)
{
	int largest_NODE = numDonuts[0];
	for (int i = 1;i < size; i++)
	{
		if (*(numDonuts+i) > largest_NODE)
			largest_NODE = *(numDonuts+i);
	}
	return largest_NODE;
}

/*make smallest number  of donuts eaten*/
int getSmallest(int* numDonuts, int size)
{
	int smallest_NODE = numDonuts[0];
	for (int i = 1; i < size; i++)
	{
		if (*(numDonuts+i) < smallest_NODE)
			smallest_NODE = *(numDonuts+i);
	}
	return smallest_NODE;
}

/*make total number  of donuts eaten*/
int getTotal(int* numDonuts, int size)
{
	int total = numDonuts[0];
	for (int i = 1; i < size; i++)
	{
		total += *(numDonuts+i);
	}
	return total;
}

/*make which store is most popular donut store*/
string getMode_location(int* location, int size)
{
	string most_popular;
	int counter = 1;
	int max = 0;
	int mode = location[0];
	for (int i = 0; i < size; i++)
	{
		if (location[i] == location[i + 1])
		{
			counter++;
			if (counter > max)
			{
				max = counter;
				mode = location[i];
			}
		}
		else
			counter = 1;
	}
	if (max = 1)
		mode = -1;
	switch (mode)
	{
	case 1:
		most_popular = "Dunkin";
		break;
	case 2:
		most_popular = "Ralphs";
		break;
	case 3:
		most_popular = "BigOs";
		break;
	case 4:
		most_popular = "Krispykreme";
		break;
	case 5:
		most_popular = "Other";
		break;
	case -1: most_popular = "None (no mode)";
	}
	return most_popular;
}

/*make which type is most popular donut type*/
string getMode_type(int* typeDonuts, int size)
{
	string most_popular;
	int counter = 1;
	int max = 0;
	int mode = typeDonuts[0];
	for (int i = 0; i < size; i++)
	{
		if (typeDonuts[i] == typeDonuts[i + 1])
		{
			counter++;
			if (counter > max)
			{
				max = counter;
				mode = typeDonuts[i];
			}
		}
		else
			counter = 1;
	}
	if (max = 1)
		mode = -1;
	switch (mode)
	{
	case 1: 
		most_popular = "Glazed";
		break;
	case 2: 
		most_popular = "Blueberry";
		break;
	case 3: 
		most_popular = "Chocolate";
		break;
	case 4: 
		most_popular = "Holes";
		break;
	case 5: 
		most_popular = "Powdered";
		break;
	case 6: 
		most_popular = "Filled";
		break;
	case -1: 
		most_popular = "None (no mode)";
		break;
	}
	return most_popular;
}