/*
	File Name:arrayFunction.cpp
	Athour: Peng Gao
	Date: April 7
	Purpose: Research of donut
*/

#include "arrayHeader.h"

/*make array*/
int* makeArray_numD(int size)
{
	int* numDonuts = new int[size];
	for (int i = 0; i < size; i++)
		*(numDonuts+i) = 0;
	return numDonuts;
}

/*get different type of donut*/
int* makeArray_tpD(int size)
{
	int* typeDonuts = new int[size];
	for(int i = 0; i < size; i++)
		*(typeDonuts+i) = 0;
	return typeDonuts;
}

/*get the loaction of each donut store*/
int* makeArray_location(int size)
{
	int* location = new int[size];
	for (int i = 0; i < size; i++)
		*(location+i) = 0;
	return location;
}

/*get largest number  of donuts eaten*/
int getLargest(int *numDonuts,int size)
{
	int largest_NODE = numDonuts[0];
	for (int i = 1;i < size; i++)
	{
		if (*(numDonuts+i) > largest_NODE)
			largest_NODE = *(numDonuts+i);
	}
	return largest_NODE;
}

/*get smallest number  of donuts eaten*/
int getSmallest(int* numDonuts, int size)
{
	int smallest_NODE = numDonuts[0];
	for (int i = 1; i < size; i++)
	{
		if (*(numDonuts+i) < smallest_NODE)
			smallest_NODE = *(numDonuts+i);
	}
	return smallest_NODE;
}

/*make total number  of donuts eaten*/
int getTotal(int* numDonuts, int size)
{
	int total = numDonuts[0];
	for (int i = 1; i < size; i++)
	{
		total += *(numDonuts+i);
	}
	return total;
}

/*make which store is most popular donut store and what kind of donut is most popular*/
string getMode (int* location, int* typeDonuts, int size)
{
	int popular = 0;
	int mode;
	int counter[6] = {0};
	if (mode = 0)
	{
		for (int i = 0; i < size; i++)
		{
			switch (*(location+i))
			{
			case 1:
				counter[0]++;
				break;
			case 2:
				counter[1]++;
				break;
			case 3:
				counter[2]++;
				break;
			case 4:
				counter[3]++;
				break;
			case 5:
				counter[4]++;
				break;
			}
			
		}
		for (int k = 0; k < 5; k++ ) //get mosst popular loaction
		{
			if (counter[k] == getLargest((int*)(&counter), 5))
			{
				popular = k + 1;
				break;
			}
		}
		switch (popular)
		{
		case 1:
			return "Dunkin";
		case 2:
			return "Ralphs";
		case 3:
			return "BigOs";
		case 4:
			return "Krispykreme";
		case 5:
			return "Other";
		}
	}
	
	else if (mode = 0)
	{
		for (int i = 0; i < size; i++)
		{
			switch (*(typeDonuts+i))
			{
			case 1:
				counter[0]++;
				break;
			case 2:
				counter[1]++;
				break;
			case 3:
				counter[2]++;
				break;
			case 4:
				counter[3]++;
				break;
			case 5:
				counter[4]++;
				break;
			case 6:
				counter[5]++;
			}
			
		}
		for (int k = 0; k < 6; k++ )//get mosst popular type
		{
			if (counter[k] == getLargest((int*)(&counter), 6))
			{
				popular = k + 1;
				break;
			}
		}
		switch (popular)
		{
		case 1: 
			return "Glazed";
		case 2: 
			return "Blueberry";
		case 3: 
			return "Chocolate";
		case 4: 
			return "Holes";
		case 5: 
			return "Powdered";
		case 6: 
			return "Filled";
		}
	}
}

