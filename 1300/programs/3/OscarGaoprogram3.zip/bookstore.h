/*
	File Name:bookstore.h
	Athour: Peng Gao
	Date: March 22
	Purpose: Bookstore
*/

#ifndef bookstore_h
#define bookstore_h

//#includes and namespace

#include<iostream>
#include<iomanip>
#include<string>

using namespace std;

//function prototypes
void function ();

//global contant variables
const int number = 12;

#endif

