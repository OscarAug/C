/*
	File Name:bookstore.cpp
	Athour: Peng Gao
	Date: March 22
	Purpose: Bookstore
*/

#include "bookstore.h"

int main ()
{
	/*Tittle*/
	cout<<"\nWelcome to FLourish and Blotts Bookstore!";
	cout<<endl<<endl;
	function ();		

	
return 0;
}

