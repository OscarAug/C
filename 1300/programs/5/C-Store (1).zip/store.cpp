#include "store.h"

int main()
{

	cout << "WELCOME TO THINK GEEK!" << endl;

	while (true)
	{
		switch (menu())
		{
		case 1:
			while (add());
			continue;
		case 2:
			if (printPopular() == true) continue;
		case 3:
			if (printItems() == true) continue;
		case 4:
			if (saveInventory() == true) break;
		}
		break;
	}
	return 0;
}