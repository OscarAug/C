/*
	File Name:functions.cpp
	Athour: Peng Gao, Ty Tabor
	Date: April 2
	Purpose: Moonpie
*/


#include "moonpie.h"


int *getsomething(int days)
{
	int *day = new int[days];
    return day;
}

void enterStolenMoonPies (int *day, int days)
{
	for (int a=0; a<days; a++)
	{
	cout<<"\nEnter the number of moon pies stolen each day.";	
	cout<<"Day "<<a + 1<<" :  ";
	cin>>*a;
	}
}

int thetotalnumber (int *day, int days)
{
	int totalnumber = 0; 
	for ( int a=0; a<days; a++)
	{
	totalnumber += *day;
	}
	return totalnumber;
}

double theaveragenumber (int *day, int days)
{
	double averagenumber = 0;
	for ( int a=0; a<days; a++)
	{
	averagenumber = *day / days;	
	}
	return averagenumber;
}

int themostnumber (int *day, int days)
{
	int mostnumber = *day;
	for ( a = 1; a<days; a++)
	{
		if (*a > mostnumber)
		mostnumber = *a;
	}
}

int theleastnumber (int *day, int days)
{
	int leastnumber = *day;
	for ( b = 0; b<days; b++)
	{
		if (*b < leastnumber)
			leastnumber = *b;
	}
}

