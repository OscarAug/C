/*
	File Name:Moonpie.h
	Athour: Peng Gao, Ty Tabor
	Date: April 2
	Purpose: Moonpie
*/

#ifndef MOONPIE_h
#define MOONPIE_h

//#includes and namespace

#include <iostream>

using namespace std;


//function prototypes
int *getsomething(int days); 
void enterStolenMoonPies ( *day,  days);
int thetotalnumber ( *day,  days);
double theaveragenumber ( *day,  days);
int theleastnumber ( *day,  days);
int themostnumber (*day,  days);


#endif