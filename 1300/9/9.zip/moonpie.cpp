/*
	File Name:Moonpie.cpp
	Athour: Peng Gao, Ty Tabor
	Date: April 2
	Purpose: Moonpie
*/


#include "moonpie.h"

int main ()
{
	int *arr;
	int days, a, totalnumber, averagenumber, mostnumber, leastnumber, b, days;
	cout<<"\nHow many days Jane steal moon pies  ";
	cin>>days;
	arr = getsomething (days);	
	enterStolenMoonPies ( *day,  days);
	thetotalnumber ( *day,  days);
	theaveragenumber ( *day,  days);
	theleastnumber ( *day,  days);
	themostnumber (*day,  days);
	
	
	cout<< "-----------------------Results-----------------------\n";
	cout<< "\nTOTAL # MOON PIES STOLEN: " <<totalnumber;
	cout <<"\nAVERAGE # MOON PIES STOLEN PER DAY:   "<<averagenumber;
	cout <<"\nMOST # MOON PIES TOLEN IN ONE DAY :   "<<mostnumber;
	cout <<"\nLEAST # MOON PIES TOLEN IN ONE DAY :   "<<leastnumber;
	
	
return 0; 
}