/*
	File Name:Moonpie.h
	Athour: Peng Gao, Ty Tabor
	Date: April 2
	Purpose: Moonpie
*/
#ifndef MOOPIE_H
#define MOOPIE_H

#include<iostream>
using namespace std;

int* makeArray(int);
void fillArray(int*, int);
int totalmoonpie(int*, int);
double averagenumber (int*, int);
int mostMoonPie(int*, int);
int leastMoonPie(int*, int);

#endif