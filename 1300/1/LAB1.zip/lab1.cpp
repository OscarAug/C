/*
	File Name: lab1.cpp
	Author: Peng Gao
	Date: January 24, 2017
	Purpose: My first C++ program!
*/

#include<iostream>
using namespace std;

int main()
{
	cout<<endl;
	cout<<"Hello, my name is Peng.\n\n";
	cout<<"This is my first lab in CSC2101!\n\n";
	
	return 0;
}