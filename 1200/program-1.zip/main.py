#prog1.py
#Peng Gao
#Computer science
#Ferruary 4, 2020 & figure out the monthly financial budget
if __name__ == '__main__':

  name = input('Enter your name: ')
  print('\nHello ' , name,'\n' )
#get the user name

  monthly_income = float (input('Please enter your monthly income: $' ))
  print('\nPlease enter your monthly experses!! \n')
#get the monthly income 

  monthly_rent = float (input('Please enter your monthly rent: $'))
  #get the monthly rent
  monthly_water = float (input('Please enter your monthly water bill: $'))
  #get the monthly water bill
  monthly_electric = float (input('Please enter your monthly electric bill: $'))
  #get the monthly electric bill
  monthly_phone = float (input('Please enter your monthly phone bill: $'))
  #get the monthly phone bill
  monthly_internet = float (input('Please enter your monthly internet bill: $'))
  #get the monthly internet bill
  monthly_car = float (input('Please enter your monthly car payment: $'))
  #get the monthly car payment
  monthly_gas = float (input('Please enter your monthly gas cost: $'))
  #get the monthly gas cost
  monthly_exspenses = float (input('Please enter other monthly exspenses: $'))
  #get the monthly exspenses without what we need before

  total_cost = monthly_rent + monthly_water + monthly_electric + monthly_phone + monthly_internet + monthly_car + monthly_gas + monthly_exspenses
  #sum the enter value together to get the total cost 
  current_balance = monthly_income - total_cost
  #figure out how much money left, use monthly income substract total cost to get
  print('\n',name, 'you have $', current_balance)
  if current_balance > 0:
    print('\n Good Job!!!')
  else :
    print('\n You should manage your money better!!')
    #the suggestion after get the current balance 








