#prog2.py
#Peng Gao
#Computer science
#February 27, 2020 & vending machine


def menu():
    print ('Welcome to My Vending Machine \n 1.Dr.Pepper - 1.75\n  2.Doritios - 2.00\n  3.Kitkat Bar - .50\n  4.Pop-tarts - 1.00\n  5.Gum - .25')
#then menu of the vending machine

def getChange(change, money):
    return int(change / money)
#the caculation for getting the change

loop = 1
choice = 0
total = 0 
payment = 0
dollar = 0
quarter = 0
dime = 0
nickle = 0
pennies = 0
#define the variables

while (loop == 1):
    menu()
    #get the menu in the loop
    choice = int(input('Please enter the number of your item or 0 to quit:'))
# set a variable to catch costumer entery
    if choice == 0:
       #when enter 0
      if total == 0:
        print ("Thank you! Standby for your total.\nYou didn't order anything!")
        break
       #when total cost is none
      else:
        print ("Thank you! Standby for your total.")
        print ('Your total is ' + str(total) + '!')
        payment = float(input("Enter your payment:"))
        # when total cost is not empty
        while(payment < total):
          payment += float(input("Not enough! Enter more money:"))
        #when the enter payment is less than the total cost
        change = payment - total
        #the formula for getting change
          
        dollar = getChange(change, 1.00)
        print ("Dollars: " + str(dollar))
        change -= float(dollar)
        #set the dollar and get how many dollars in the change
        quarter = getChange(change, 0.25)
        print ("Quarters : " + str(quarter))
        change -= 0.25*quarter
        #set the quater and get how many quarters in the change
        dime = getChange(change, 0.1)
        print ("Dimes: " + str(dime))
        change -= 0.1*dime
        #set the dime and get how many dimes in the change
        nickle = getChange(change, 0.05)
        print ("Nickles: " + str(nickle))
        change -= 0.05*nickle
        #set the nickle and get how many nickles in the change
        pennies = getChange(change, 0.01)
        print ("Pennies: " + str(pennies))
        loop = 0
        #set the penny and get how many pennies in the change

    elif choice == 1:
        print ("You bought one can of Dr. Pepper for 1.75")   
        #when costumer enter 1 return the corresponding product and price
        total += 1.75
        #add in the total cost when choose this product
       
    elif choice == 2:
        print ("You bought one bag of Doritos for 2.00")   
        #when costumer enter 2 return the corresponding product and price  
        total += 2.00
        #add in the total cost when choose this product
    
    elif choice == 3:
        print ("You bought one bag of Kitkat Bar for 0.50")
        #when costumer enter 3 return the corresponding product and price  
        total += 0.5
        #add in the total cost when choose this product
    
    elif choice == 4:
        print ("You bought one bag of Pop-tarts for 1.00")
        #when costumer enter 4 return the corresponding product and price    
        total += 1.00
        #add in the total cost when choose this product
    
    elif choice == 5:
        print ("You bought one bag of Gum for 0.50")    
        #when costumer enter 5 return the corresponding product and price  
        total += 0.25
        #add in the total cost when choose this product

    else:
        print ("Invalid entry!")
    #when costumer enter the number except 0,1,2,3,4,5
    
