#Peng Gao
#final lab - encrypt and decrypt

import os.path

#encrypt function
def encryptFile(Lst):
    newLst = []
    for i in range (0, len(Lst), 1):
        line = ""
        for j in range(0, len(Lst[i]), 1):
            line += chr(ord(Lst[i][j]) + 5)
        newLst.append(line + "\n")
    return newLst

#decrypt function
def decryptFile(Lst):
    newLst = []
    for i in range (0, len(Lst), 1):
        line = ""
        for j in range(0, len(Lst[i]), 1):
            line += chr(ord(Lst[i][j]) - 5)
        newLst.append(line + "\n")
    return newLst

#read the data from enter file
def getInput():
    try:
        filename = input("Enter filename you want to read from: ")
        print("Warning ! Writing to a file will earse previous content!!")
        if os.path.isfile(filename):
            myFile = open(filename, "r")
            list = myFile.read().split("\n")
            myFile.close()
            return list
        else:
            print ("File not exist")        
    except IOError:
        print("File not exist")
   
#send out the new file which did the choicen work
def wFile(Lst):
    try:
        filename = input("Enter filename you want to write to: ")
        myFile = open(filename, "w")
        for data in Lst:
                myFile.write(data)
                myFile.write('\n')
    except IOError:
        print("File not exist")
    
    myFile.close()

#menu
def menu():
    print("************ MAIN MENU **************\n")
    choice = input("""
                      1: Encryption
                      2: Decryption
                      Please enter your choice: """)
    #enter choice
    if (choice == "1" ):
        list = getInput()
        list = encryptFile(list)
        wFile(list)
    elif (choice == "2" ):
        list = getInput()
        list = decryptFile(list)
        wFile(list)
    else:
        print("Invalid selection! ")
        menu()

menu()