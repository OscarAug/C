# Peng Gao    
# program 5 - House: A Treasure Finding "Game"
#2020/4/26
#computer science

import sys
import math
import random
import os.path
import copy
import pandas as pd

#build hoouse function
def build_house():
  print ("Please enter the house fille: ")
  house_file = input()
  housefp = open(house_file, "r")
  myhouse = []
  line = housefp.readline()
  while line:
    myhouse.append(list(line))
    line = housefp.readline()
  return myhouse

#print house function
#h-house, sr-row, sc-col
def print_house(h,sr,sc):
  th = copy.deepcopy(h)
  th[sr][sc] = "@"
  for i in th:
    print(''.join(str(x) for x in i), end='')

#print key function
def print_keys(keys):
	at_least_one_k = False
	print("Keys:", end='')
	#print("Keys:")
	for k in range(0, len(keys)):
		if(keys[k] == True):
			print(str(k) + ", ", end='')
			#print(str(k) + ", ")
			at_least_one_k = True
	if(not at_least_one_k):
		print("There is no keys were collected ", end='')
		#print("There is no keys were collected ")

def room(h, sr, sc):
	if(h[sr][sc] == '*'):
		return False
	else:
		return True


def get_treasure(h, sr, sc):
	if(h[sr][sc] == 't'):
		return True
	else:
		return False


def stop():
	print("Sorry, you cant go that way.")

#is at the dooor function
def is_door(h, sr, sc):
	if(h[sr][sc] in ['5','6','7','8','9']):
		return True
	else:
		return False

#is at the key function
def is_key(h, sr, sc):
	if(h[sr][sc] in ['0','1','2','3','4']):
		return True
	else:
		return False

#get key function
def get_key(h, keys, sr, sc):
	loc = h[sr][sc]
	if(is_key(h, sr, sc)):
		keys[int(loc)] = True
		h[sr][sc] = ' '
	else:
		return False

#can unlockdoor function
def can_unlock(h, keys, sr, sc):
	loc = h[sr][sc]
	if(is_door(h, sr, sc) and keys[int(loc)-5]):
		h[sr][sc] = ' '
		return True
	else:
		return False

#open door function
def open_door():
	print("You unlocked the door!")




def main():

	# Initialize variables
	keys = 2
	num_treasures = 2 # total number of treasures in the house
	t_count = 0 # number of treasures found
	t_loc = False # if location is a treasure ; if there is a 't' in our way or not
	k_loc = False # if location is a key
	passage = False # if can go through door
	valid_move = False 
	quit = False

	# Read the house file into a matrix (list of lists)
	house = build_house()

	# Set the spawn location
	spawn_r = 2
	spawn_c = 3

	# Print instructions
	print("Move around the house by entering 'W' for North, 'S' for South, 'A' for East, or 'D' for West.")
	print("You cannot move through walls (marked by the '*' characters).")
	print("Find the keys and collect all the treaure!")
	print_house(house, spawn_r, spawn_c)

	# Set the  locations
	trav_r = cur_r = spawn_r
	trav_c = cur_c = spawn_c

	while(t_count < num_treasures):
		command = input("Move: ").upper()
		print_keys(keys)
		print("\nTreasure:", str(t_count) + '/' + str(num_treasures))

		trav_r = cur_r
		trav_c = cur_c
    
    #set the choices
		if(command == 'W'):
			trav_r = cur_r - 1
		elif(command == 'S'):
			trav_r = cur_r + 1
		elif(command == 'A'):
			trav_c = cur_c - 1
		elif(command == 'D'):
			trav_c = cur_c + 1
		elif(command == "QUIT"):
			quit = True
			break
		else:
			print("Not a valid direction, try again.")
			continue

		loc = house[trav_r][trav_c]
		valid_move = room(house, trav_r, trav_c)
		t_loc = get_treasure(house, trav_r, trav_c)
		k_loc = get_key(house, keys, trav_r, trav_c)
		passage = can_unlock(house, keys, trav_r, trav_c)

		# If picking up treasure
		if(t_loc):
			house[trav_r][trav_c] = ' '
			t_count += 1

		# If accessing a door
		if(passage): open_door()

		# Can not go through door without proper key
		if(is_door(house, trav_r, trav_c) and not keys[int(loc)-5]):
			valid_move = False

		if(not valid_move): stop()
		else:
			cur_r = trav_r
			cur_c = trav_c

		#print	
		print_house(house, cur_r, cur_c)

	if(not quit and t_count >= num_treasures):
		print("Congrats, you found all the treasure!")
	else:
		print("You quit the game.")

if __name__ == "__main__":
	main()