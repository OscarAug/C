#Peng Gao & computer science
#Program 3: hangman game
#2020/4/13

import random

def draw_hang_loser():
    print(" _________     \n")
    print("|         |    \n")
    print("|         0    \n")
    print("|        /|\   \n")
    print("|        / \   \n")
    print("|              \n")
    print("|              \n")

def draw_hang_head_body_legs_la():
    print(" _________     \n")
    print("|         |    \n")
    print("|         0    \n")
    print("|         |\   \n")
    print("|        / \   \n")
    print("|              \n")
    print("|              \n")

def draw_hang_head_body_legs():
    print(" _________     \n")
    print("|         |    \n")
    print("|         0    \n")
    print("|         |    \n")
    print("|        / \   \n")
    print("|              \n")
    print("|              \n")

def draw_hang_head_body_ll():
    print(" _________     \n")
    print("|         |    \n")
    print("|         0    \n")
    print("|         |    \n")
    print("|          \   \n")
    print("|              \n")
    print("|              \n")   

def draw_hang_head_body():
    print(" _________     \n")
    print("|         |    \n")
    print("|         0    \n")
    print("|         |    \n")
    print("|              \n")
    print("|              \n")
    print("|              \n")

def draw_hang_head():
    print(" _________     \n")
    print("|         |    \n")
    print("|         0    \n")
    print("|              \n")
    print("|              \n")
    print("|              \n")
    print("|              \n")

def draw_hang_scaffold():
    print(" _________     \n")
    print("|         |    \n")
    print("|              \n")
    print("|              \n")
    print("|              \n")
    print("|              \n")
    print("|              \n")

def draw_hangman(state):
    if state == 0:
        draw_hang_scaffold()
    elif state == 1:
        draw_hang_head()
    elif state == 2:
        draw_hang_head_body()
    elif state == 3:
        draw_hang_head_body_ll()
    elif state == 4:
        draw_hang_head_body_legs()
    elif state == 5:
       draw_hang_head_body_legs_la()
    elif state == 6:
        draw_hang_loser()
        
        
def blanks_gone(s):
  # You must implement this
  # Look up the find() function for strings

  #takes a string as a parameter,  returns either True or False
  s.find("_") 
  if s.find("_") == 1:
    return True
  return False

def replace_all(orig, working, ch):
  done = False
  count = 0
  while not done:
    idx = orig.find(ch)
    if idx != -1:
      count = count + 1
      orig = orig[:idx] + "_" + orig[idx+1:]
      working = working[:idx] + ch + working[idx+1:]
    else:
      done = True
  return count != 0, orig, working 

 
#  random get
def random_word(fname):
	word = open(fname).read().splitlines()
	return random.choice(word)
  
def main():
  # You must implement this
  state = 0
  losingState = 6 #have 6 stage 
  tmp = random_word("Words.txt")
  word = tmp.lower() 
  # get the word with lower case
  places = "_____ __ ____" 
  # the spaces at begin

  player = False 
  # at the begining, nobody is winner

  while player == False and state != losingState: 
    # start game
    draw_hangman(state)
    print(places)
    print("Enter a charactor: ")
    char = input()
    ret = replace_all(word, places, char)
    success,word,places = ret
    if success == False: 
      #  do the judgement 
      state += 1
    blanks = blanks_gone(places)
    if blanks == True:
      player = True
  draw_hangman(state)
  if player == True: 
    #  guess correct
    print("Victory")
  else:
    print("Defeat")

    
main()

    
